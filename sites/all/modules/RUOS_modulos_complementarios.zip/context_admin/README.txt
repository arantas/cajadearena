;$Id: README.txt,v 1.2 2010/03/11 04:42:45 eclipsegc Exp $

STATEMENT OF PURPOSE
====================

Contextual Administration is intended to be a simple tool for deploying custom administrations on your site, or as an exportable within your module.  In short anything you can put on a page, context_admin is a simple solution to doing so without the overhead of panels.

INSTALLATION
============


CONFIGURATION
=============


THEMING
=======


NOTE
====


AUTHORS & COPYRIGHT
===================
Context admin  was written by Kristopher Vanderwater

Context admin  Copyright (c) 2010 Meridian Data Systems, Inc. (dba The Worx Company)

This module is licensed under the  GPL v2. See LICENSE.txt for details.
